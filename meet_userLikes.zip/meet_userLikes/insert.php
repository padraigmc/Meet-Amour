    




<?php
$dbServerName = "localhost";
            
            
            $dbUsername = "root";
            $dbPassword = "";
            $dbName = "meetamour";
        
            // Create connection
            $conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);
        
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
			$time = date("H:i:s");
						$day = date("Y-m-d");
						$dateUploaded = $day . " " . $time;
$sql = "SELECT * FROM user WHERE userID='1'";

if($result = $conn->query($sql)){
	if($result->num_rows > 0){
		while($row = $result->fetch_array()){
			$username = $row['username'] ;
			$userid = $row['userID'];
/*echo  "user ID= " . $row['userID'] . " User Name=" . $row['username'] ;*/

}
$result->free();
 } else{
        echo "No records matching your query were found.";
    }
    } else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}

						
                         $sql = "INSERT INTO `like` (`likeID`, `fromUserID`, `toUserID`, `dateLiked`) VALUES ('', '$userid', '11', '$dateUploaded')";


                         if (!mysqli_query($conn,$sql)){
                         	echo "Not Inserted";
                         } else {
                         	echo "Inserted";
                         }



header( "refresh:0;url=user.php" );
                        ?> 